import os

BASE_APP_DIR = os.path.dirname(__file__)

KEYS_DIR = os.path.join(BASE_APP_DIR, 'keys')

TRANSCODING_SERVICE_URL = 'http://127.0.0.1:9090/backend/'

FILE_SERVICE_URL = 'http://127.0.0.1:7000/api/'

INPUT_SEGMENT_FOLDER = '/tmp/process'

OUTPUT_SEGMENT_FOLDER = '/tmp/output'

BROKER_URL = 'amqp://to_daemon_rabbit_user:GxWHg0TLvzHuFIzv6tGW@localhost:5672//TOENV'

CELERY_RESULT_DBURI = 'mysql://to_remote_user:7610Zp18M4t4Gqk2J2ur@127.0.0.1:3306/transcoding_service'

KEY_SPLIT_MACHINE = KEY_MUX_MACHINE = '/home/transcoding_user/dev_key.pem'

import getpass
WORKER_USERNAME = FTP_USERNAME = getpass.getuser()

FTP_PASSWORD = '16/05/91'

FTP_PORT = 21

SPLIT_MACHINE_IP = MUX_MACHINE_IP = '127.0.0.1'