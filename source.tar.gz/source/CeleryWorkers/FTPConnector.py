import os
import time
import shutil
import ftplib
import ftputil
import ftputil.session

from CeleryWorkers.settings import FTP_USERNAME
from CeleryWorkers.settings import FTP_PASSWORD
from CeleryWorkers.settings import FTP_PORT


class FTPConnector:
    ftp_instance = None

    def __init__(self, host, user=FTP_USERNAME, password=FTP_PASSWORD):
        session_factory = ftputil.session.session_factory(
            base_class=ftplib.FTP,
            port=FTP_PORT,
            encrypt_data_channel=False,
            debug_level=0)
        try:
            self.ftp_instance = ftputil.FTPHost(host, user, password, session_factory=session_factory)
        except Exception:
            time.sleep(60)
            self.ftp_instance = ftputil.FTPHost(host, user, password, session_factory=session_factory)

    def get_instance(self):
        """
        :rtype: :class:`ftputil.FTPHost`
        :return: FTPHost instance
        """
        return self.ftp_instance

    def create_folder(self, folder_path):
        """
        :type folder_path: str`
        :param folder_path: The folder path

        :rtype: bool
        :return: The result
        """
        if self.get_instance().path.isfile(folder_path):
            self.get_instance().remove(folder_path)
        if not self.get_instance().path.isdir(folder_path):
            self.get_instance().makedirs(folder_path)
        return True

    def upload_file(self, local_path, remote_path):
        """
        :type local_path: str`
        :param local_path: The local path

        :type remote_path: str`
        :param remote_path: The remote path

        :rtype: bool
        :return: The result
        """
        local_path = str(local_path)
        remote_path = str(remote_path)
        # check if file does not exist
        if not os.path.isfile(local_path):
            raise Exception('File does not exist')
        # create dest folder
        self.create_folder(remote_path)
        filename = os.path.basename(local_path)
        remote_path = self.get_instance().path.join(remote_path, filename)
        # copy file to remote storage
        self.get_instance().upload(local_path, remote_path)
        return self.get_instance().path.isfile(remote_path)

    def download_file(self, remote_path, local_path):
        """
        :type local_path: str`
        :param local_path: The local path

        :type remote_path: str`
        :param remote_path: The remote path

        :rtype: bool
        :return: The result
        """
        remote_path = str(remote_path)
        local_path = str(local_path)
        # check if file does not exist
        if not self.get_instance().path.isfile(remote_path):
            raise Exception('File does not exist')
        if os.path.isfile(local_path):
            os.remove(local_path)
        if not os.path.isdir(local_path):
            os.makedirs(local_path)
        filename = self.get_instance().path.basename(remote_path)
        local_path = os.path.join(local_path, filename)
        # copy file to local storage
        self.get_instance().download(remote_path, local_path)
        return os.path.isfile(local_path)

    def remove_file(self, remote_path):
        """
        :type remote_path: str`
        :param remote_path: The remote path

        :rtype: bool
        :return: The result
        """
        if self.get_instance().path.isfile(remote_path):
            self.get_instance().remove(remote_path)
            return True
        return False

    def remove_folder(self, remote_path):
        """
        :type remote_path: str`
        :param remote_path: The remote path

        :rtype: bool
        :return: The result
        """
        if self.get_instance().path.isdir(remote_path):
            self.get_instance().rmtree(remote_path)
            return True
        return False