

VALID_INPUT_FILE_EXTENSIONS = ('mkv', 'avi', 'm2ts', 'ts', 'mp4', 'vob')
DEFAULT_FFMPEG_COMMAND = 'ffmpeg'
DEFAULT_FFPROBE_COMMAND = 'ffprobe'
DEFAULT_MEDIAINFO_COMMAND = 'mediainfo'